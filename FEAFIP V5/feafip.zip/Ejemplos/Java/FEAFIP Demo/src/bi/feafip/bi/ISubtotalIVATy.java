package feafip  ;

import com4j.*;

@IID("{873012B5-0A40-440E-9F18-ED81C3C7AD4F}")
public interface ISubtotalIVATy extends Com4jObject {
  // Methods:
  // Properties:
}
