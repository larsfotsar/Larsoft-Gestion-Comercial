package feafip  ;

import com4j.*;

@IID("{572B401B-91D9-46CA-85A7-ED286B14693B}")
public interface IItemTy extends Com4jObject {
  // Methods:
  // Properties:
}
